$(function() {
	$('.close').click(function() {
		$('.toasts-top-right').remove()
	});
});
