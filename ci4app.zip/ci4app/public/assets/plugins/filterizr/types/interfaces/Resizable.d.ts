export interface Resizable {
    readonly dimensions: {
        width: number;
        height: number;
    };
}
